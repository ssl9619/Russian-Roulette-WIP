function credits_menu() {
    
}